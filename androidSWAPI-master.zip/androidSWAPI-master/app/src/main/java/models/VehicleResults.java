package models;

import java.util.List;

/**
 * Created by User on 27/10/2016.
 */
public class VehicleResults
{
    public List<Vehicle> results;
}
